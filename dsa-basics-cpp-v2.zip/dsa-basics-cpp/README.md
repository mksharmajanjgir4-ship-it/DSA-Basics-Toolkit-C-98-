# DSA Basics Toolkit (C++98)

A clean, beginner-friendly C++98 console program covering core array algorithms: Linear Search, Bubble Sort, and Binary Search.

## Included Algorithms
- **Linear Search:** Scans elements sequentially ($O(n)$ time).
- **Bubble Sort:** Sorts ascending with early exit optimization ($O(n^2)$ worst-case time).
- **Binary Search:** Searches sorted arrays by halving the range ($O(\log n)$ time).

## Build and Run
```bash
g++ -std=c++98 -Wall -Wextra main.cpp -o dsa_toolkit
./dsa_toolkit
```
