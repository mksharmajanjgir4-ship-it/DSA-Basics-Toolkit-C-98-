#include <iostream>

using namespace std;

const int MAX_SIZE = 100;

int linearSearch(const int arr[], int n, int target) {
    for (int i = 0; i < n; ++i) {
        if (arr[i] == target) {
            return i;
        }
    }
    return -1;
}

int binarySearch(const int arr[], int n, int target) {
    int left = 0;
    int right = n - 1;
    while (left <= right) {
        int mid = left + (right - left) / 2;
        if (arr[mid] == target) {
            return mid;
        } else if (arr[mid] < target) {
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }
    return -1;
}

void bubbleSort(int arr[], int n) {
    for (int i = 0; i < n - 1; ++i) {
        bool swapped = false;
        for (int j = 0; j < n - i - 1; ++j) {
            if (arr[j] > arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
                swapped = true;
            }
        }
        if (!swapped) {
            break;
        }
    }
}

void printArray(const int arr[], int n) {
    cout << "[ ";
    for (int i = 0; i < n; ++i) {
        cout << arr[i] << (i + 1 < n ? ", " : " ");
    }
    cout << "]\n";
}

int main() {
    int arr[MAX_SIZE];
    int n = 0;
    int choice = 0;

    cout << "Enter number of elements (1 to " << MAX_SIZE << "): ";
    cin >> n;
    if (n < 1 || n > MAX_SIZE) {
        cout << "Invalid array size.\n";
        return 1;
    }

    for (int i = 0; i < n; ++i) {
        cout << "Element " << (i + 1) << ": ";
        cin >> arr[i];
    }

    while (true) {
        cout << "\n=== DSA Basics Toolkit (C++98) ===\n";
        cout << "1. Display Array\n";
        cout << "2. Linear Search\n";
        cout << "3. Bubble Sort (Ascending)\n";
        cout << "4. Binary Search (Requires Sorted Array)\n";
        cout << "5. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        if (choice == 1) {
            printArray(arr, n);
        } else if (choice == 2) {
            int target = 0;
            cout << "Enter target value: ";
            cin >> target;
            int idx = linearSearch(arr, n, target);
            if (idx != -1) {
                cout << "Found at 0-based index: " << idx << "\n";
            } else {
                cout << "Element not found.\n";
            }
        } else if (choice == 3) {
            bubbleSort(arr, n);
            cout << "Array sorted: ";
            printArray(arr, n);
        } else if (choice == 4) {
            int target = 0;
            cout << "Enter target value: ";
            cin >> target;
            int idx = binarySearch(arr, n, target);
            if (idx != -1) {
                cout << "Found at 0-based index: " << idx << "\n";
            } else {
                cout << "Element not found (ensure array is sorted in ascending order).\n";
            }
        } else if (choice == 5) {
            cout << "Exiting.\n";
            break;
        } else {
            cout << "Invalid option.\n";
        }
    }

    return 0;
}
